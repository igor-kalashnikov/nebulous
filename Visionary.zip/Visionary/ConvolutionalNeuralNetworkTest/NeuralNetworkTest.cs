﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using NUnit.Mocks;
using Visionary.ConvolutionalNeuralNetwork;

namespace ConvolutionalNeuralNetworkTest
{
    [TestFixture]
    internal class NeuralNetworkTest
    {
        [Test]
        public void PeriodicWeightSanityCheck()
        {
            
        }
    }
}
