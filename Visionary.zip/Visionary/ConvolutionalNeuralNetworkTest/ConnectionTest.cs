﻿using NUnit.Framework;

namespace Visionary.ConvolutionalNeuralNetworkTest
{
    [TestFixture]
    internal class ConnectionTest
    {
        
    }
}
